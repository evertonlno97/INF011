/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package questao2.main;

import interfaces.Target;
import questao2.Adapter.Adapter;

/**
 *
 * @author weverton
 */
public class main {
    
    public static void main(String[] args) {
        
        Target adapted = new Adapter(1,2);
        adapted.moverAdapter(3, 2);
        adapted.printPoint(); 
        
    }
    
}
